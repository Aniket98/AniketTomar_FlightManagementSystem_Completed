package com.capgemini.myapp.controller;

import java.util.Scanner;

public class LogOutServiceImpl {
	
	Scanner scan = new Scanner(System.in);
	
	public LogOutServiceImpl() {
		
		System.out.print("\nLog Out? ");
		
		String logOut = new String();
		logOut = scan.nextLine();
		
		if(logOut.equals("yes")) {
			System.out.print("\nLogged Out Successfully.");
			System.exit(0);
		}
		
		else {
			//System.out.print("\nYou are still logged in. Exiting the flight booking application.");
		}
		
	}
}
