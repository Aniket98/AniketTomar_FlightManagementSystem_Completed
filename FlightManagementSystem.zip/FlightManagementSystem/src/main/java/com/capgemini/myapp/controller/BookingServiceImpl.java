package com.capgemini.myapp.controller;

import java.math.BigInteger;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.myapp.dao.CollectionUtil;
import com.capgemini.myapp.model.*;


public class BookingServiceImpl {
	
	Scanner scan = new Scanner(System.in);
		
	public void addBooking() {
		
		System.out.print("\nEnter Flight Number to Book: ");
		BigInteger flightNumber = scan.nextBigInteger();
		scan.nextLine();
		System.out.print("\n");
		
		boolean isBookingAvailable = viewBooking(flightNumber);
		
		if(isBookingAvailable) {
			
			System.out.print("\nConfirm Booking? yes/no : ");
			String confirmBooking = scan.nextLine();
			
			if(confirmBooking.equals("yes")) {
				System.out.println("\n>> Booking Confirmed. Ticket Generated.");
				System.out.println("    ---------------------------------");
				System.out.println(">> | Your Unique Ticket ID = 988574 |");
				System.out.println("    ---------------------------------");
			}
			
			else {
				System.out.println(">> Booking Cancelled");
			}
		}
		
		else {
			System.out.println(">> No Booking Made.");
		}
		
		new LogOutServiceImpl();
	}
	
	public boolean viewBooking(BigInteger flightNumber) {
		//Retrieves a booking made by user based on booking id

		CollectionUtil flightsDatabase = new CollectionUtil();
		
		boolean isFlightAvailable = false;
		
		for(ScheduledFlight temp : flightsDatabase.getFlightDatabase()) {
			
			if(
					temp.getFlight().getFlightNumber().equals(flightNumber)
					
					) {
				System.out.print(temp.getSchedule().getSourceAirport().getAirportLocation() + "       \t");
				System.out.print(temp.getSchedule().getDestinationAirport().getAirportLocation() + "             \t");
				System.out.print(temp.getSchedule().getDepartureTime() + "       \t");
				System.out.print(temp.getSchedule().getArrivalTime() + "       \t");
				System.out.print(temp.getFlight().getFlightNumber() + "             \t");
				System.out.print(temp.getFlight().getCarrierName() + "\n");
				
				isFlightAvailable = true;
				
				break;
				
			}			
		}
		
		if(isFlightAvailable) {
			return true;
		}
		
		else {
			System.out.println("\n>> Sorry, no flight exists with the provided flight number.");
			return false;
		}

	}
		
	public void deleteBooking() {
		//Details a previous booking identifiable by the 'booking id'
		
		BigInteger bookingId;
		
		boolean isBookingIdValid = false;
		
		while(!isBookingIdValid) {
		
			try {
				System.out.print("\nEnter Your Booking Id: ");
				
				bookingId = scan.nextBigInteger();
				scan.nextLine();
				
				System.out.println("\n>> Booking Cancelled Successfully.");
				
				new LogOutServiceImpl();
			}
			
			catch(Exception e) {
				scan.nextLine();
				System.out.println("\nPlease Enter Integer Value.");
			}
		}
		
	}


}
