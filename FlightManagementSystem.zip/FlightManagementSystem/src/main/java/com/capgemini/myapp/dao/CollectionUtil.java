package com.capgemini.myapp.dao;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.myapp.model.Airport;
import com.capgemini.myapp.model.Flight;
import com.capgemini.myapp.model.Schedule;
import com.capgemini.myapp.model.ScheduledFlight;

public class CollectionUtil {

	List<ScheduledFlight> listOfFlights = new ArrayList<ScheduledFlight>(); //FLights Database

	//-------------------------------------- Getter Function for Retrieving Flight Database -----------------------------------------
	
		public List<ScheduledFlight> getFlightDatabase() {
			return listOfFlights;
		}

	//------------------------------------- Constructor Adding Flights to Flights Database --------------------------------------------
	
	public CollectionUtil() {
		
		//Add Flight
		listOfFlights.add(new ScheduledFlight(

				new Flight(
						new BigInteger("112233"),
						"SJ223",
						"SpiceJet",
						new Integer(520)
						),
				new Integer(500),
				new Schedule(
						new Airport("Indira Gandhi Int. Airport", "DL3342", "Delhi"),
						new Airport("Chhatrapati Shivaji Airport", "MMB2342", "Mumbai"),
						LocalDate.of(2020, 03, 01),
						LocalDate.of(2020, 03, 01)
						)
				
				));

		//Add Flight
				listOfFlights.add(new ScheduledFlight(

						new Flight(
								new BigInteger("112244"),
								"IN345",
								"Indigo",
								new Integer(520)
								),
						new Integer(500),
						new Schedule(
								new Airport("Indira Gandhi Int. Airport", "DL3342", "Delhi"),
								new Airport("Chhatrapati Shivaji Airport", "MMB2342", "Mumbai"),								
								LocalDate.of(2020, 03, 02),
								LocalDate.of(2020, 03, 01)
								)
						
						));

				//Add Flight
				listOfFlights.add(new ScheduledFlight(

						new Flight(
								new BigInteger("112255"),
								"KN564",
								"KingFisher",
								new Integer(520)
								),
						new Integer(500),
						new Schedule(
								new Airport("Indira Gandhi Int. Airport", "DL3342", "Delhi"),
								new Airport("Chhatrapati Shivaji Airport", "MMB2342", "Mumbai"),
								LocalDate.of(2020, 03, 02),
								LocalDate.of(2020, 03, 01)
								)
						
						));

				//Add Flight
				listOfFlights.add(new ScheduledFlight(

						new Flight(
								new BigInteger("112266"),
								"AI231",
								"AirIndia",
								new Integer(520)
								),
						new Integer(500),
						new Schedule(
								new Airport("Indira Gandhi Int. Airport", "DL3342", "Delhi"),
								new Airport("Chhatrapati Shivaji Airport", "MMB2342", "Mumbai"),
								LocalDate.of(2020, 03, 03),
								LocalDate.of(2020, 03, 01)
								)
						
						));

				//Add Flight
				listOfFlights.add(new ScheduledFlight(

						new Flight(
								new BigInteger("112277"),
								"QT124",
								"Qatar",
								new Integer(520)
								),
						new Integer(500),
						new Schedule(
								new Airport("Indira Gandhi Int. Airport", "DL3342", "Delhi"),
								new Airport("Chhatrapati Shivaji Airport", "MMB2342", "Mumbai"),
								LocalDate.of(2020, 03, 03),
								LocalDate.of(2020, 03, 01)
								)
						
						));

				//Add Flight
				listOfFlights.add(new ScheduledFlight(

						new Flight(
								new BigInteger("112288"),
								"IN124",
								"Indigo",
								new Integer(520)
								),
						new Integer(500),
						new Schedule(
								new Airport("Indira Gandhi Int. Airport", "DL3342", "Delhi"),
								new Airport("Bangalore Airport", "BNG2342", "Bangalore"),
								LocalDate.of(2020, 03, 02),
								LocalDate.of(2020, 03, 01)
								)
						
						));

				//Add Flight
				listOfFlights.add(new ScheduledFlight(

						new Flight(
								new BigInteger("112299"),
								"SJ574",
								"SpiceJet",
								new Integer(520)
								),
						new Integer(500),
						new Schedule(
								new Airport("Indira Gandhi Int. Airport", "DL3342", "Delhi"),
								new Airport("Bangalore Airport", "BNG2342", "Bangalore"),
								LocalDate.of(2020, 03, 02),
								LocalDate.of(2020, 03, 01)
								)
						
						));
				
				// ------------------------------------------------------------------------------------------------------------------------

				/*						
										
						List<ScheduledFlight> listOfFlights = new ArrayList<ScheduledFlight>();

						//Add Flight
								listOfFlights.add(new ScheduledFlight(

										new Flight(
												new BigInteger("112233"),
												"SJ223",
												"SpiceJet",
												new Integer(520)
												),
										new Integer(500),
										new Schedule(
												new Airport("Indira Gandhi Int. Airport", "DL3342", "Delhi"),
												new Airport("Chhatrapati Shivaji Airport", "MMB2342", "Mumbai"),
												LocalDate.of(2020, 03, 01),
												LocalDate.of(2020, 03, 01)
												)
										
										));
								System.out.println("ok  till here");
						
								for(int i=1;i<3;i++) {System.out.println(listOfFlights);}
								
								//Serializing Flights List
								try{												
//									FileOutputStream file = new FileOutputStream("listOFScheduledFlights.txt");
									FileOutputStream file = new FileOutputStream("listOFFlights.txt");
									ObjectOutputStream out = new ObjectOutputStream(file);
									
									out.writeObject(listOfFlights);
					//				out.flush();
									out.close();
									file.close();
									
									System.out.println("Successfully Serialized Flights List");

								}
								
									catch(IOException ex) {
									System.out.println("IOException is caught (during Serialization)");
								}

//								@SuppressWarnings("unchecked");

								//De-serializing Flights List
								try{

//									List<ScheduledFlight> listOfFlights;
									
									FileInputStream file = new FileInputStream("listOfScheduledFlights.txt");
									ObjectInputStream in = new ObjectInputStream(file);
									
									listOfFlights = (List<ScheduledFlight>)in.readObject();
									myListOfFlights = listOfFlights;
									
									in.close();
									file.close();

									System.out.println("____________________________ Successfully De-Serialized Flights List ____________________________\n\n");

								}
										
								catch(IOException ex) {
									System.out.println("IOException is caught (during De-Serializaion)");
								}

								catch(ClassNotFoundException ex) {
									System.out.println("IOException is caught (during De-Serializaion)");
								}

				*/						
				// ------------------------------------------------------------------------------------------------------------------------				
	}
}
