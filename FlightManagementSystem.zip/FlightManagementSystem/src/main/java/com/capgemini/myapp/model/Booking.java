package com.capgemini.myapp.model;
/*

package com.capgemini.myapp.dto;

import java.math.BigInteger;
import java.util.Date;
import java.util.*;

public class Booking {
	
	private BigInteger bookingId;
	private BigInteger flightNumber;
	
	public Booking() {

	}

	public Booking(BigInteger bookingId, BigInteger flightNumber) {
		super();
		this.bookingId = bookingId;
		this.flightNumber = flightNumber;
	}
	
	public BigInteger getBookingId() {
		return bookingId;
	}

	public void setBookingId(BigInteger bookingId) {
		this.bookingId = bookingId;
	}

	public BigInteger getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(BigInteger flightNumber) {
		this.flightNumber = flightNumber;
	}
	
}

*/