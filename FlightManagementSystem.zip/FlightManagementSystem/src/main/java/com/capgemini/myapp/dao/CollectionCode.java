package com.capgemini.myapp.dao;

import com.capgemini.myapp.controller.BookingServiceImpl;
import com.capgemini.myapp.controller.SearchFlightsServiceImpl;

import java.util.Scanner;

public class CollectionCode {
	
	boolean startMenu = true;
	
	public void userMenu(String username) {

		while(true) {
		
		Scanner scan = new Scanner(System.in);
		
		//Menu
		System.out.println("\nWelcome " + username + "\n");
		System.out.println("1 - Book Flight");
		System.out.println("2 - Search Flights");
		System.out.println("3 - Cancel Booking" + "\n");
					


		System.out.print("Select Option: ");
		int option = scan.nextInt();

		System.out.println("___________________________________");

		//Select an option
		switch (option) {
		
			case 1:
				makeBooking();
				break;
				
			case 2:
				searchFlights();
				break;
			
			case 3:
				cancelBooking();
				break;
				
			default:
				System.out.println("Incorrect Selection. Please Try Again.");
		
		}
		}

	}
	
	public void makeBooking() {
		BookingServiceImpl booking = new BookingServiceImpl(); //Setup Booking
		booking.addBooking();
	}
	
	public void searchFlights() {
		SearchFlightsServiceImpl flights = new SearchFlightsServiceImpl(); //Search or View Flights
		flights.searchFlightsFromDatabase();
	}
	
	public void cancelBooking() {
		BookingServiceImpl booking2 = new BookingServiceImpl(); //Cancel Booking
		booking2.deleteBooking();
	}

}
