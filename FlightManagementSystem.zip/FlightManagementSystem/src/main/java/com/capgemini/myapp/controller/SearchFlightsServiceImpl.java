package com.capgemini.myapp.controller;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.myapp.model.*;

import java.time.*;
import com.capgemini.myapp.dao.*;

public class SearchFlightsServiceImpl {
	
	Scanner scan = new Scanner(System.in);
	
/*	List<ScheduledFlight> myListOfFlights; */
	
	List<ScheduledFlight> listOfFlights = new ArrayList<ScheduledFlight>(); //FLights Database
	
	public void searchFlightsFromDatabase(){
		
		System.out.println("\nSearch Your Flights\n");
				
		//Ask for Source, Destination and Time
		System.out.print("Source: ");
		String sourceLocation = new String();
		sourceLocation = scan.nextLine();
		
		System.out.print("Destination: ");
		String destinationLocation = new String();
		destinationLocation = scan.nextLine();
		
		System.out.println("");
		
		boolean isFlightAvailable = false; 

		//Display Available Flights
		System.out.print("Source       \tDestination       \tDeparture Date       \tArrival Date       \tFlight Number       \tFlight Carrier\n");
		System.out.println("--------------------------------------------------------------------------------------------------------------------------------");		
		
		CollectionUtil flightDatabase = new CollectionUtil();
		listOfFlights = flightDatabase.getFlightDatabase();		

		for(ScheduledFlight temp : listOfFlights) {
			
			if(
					temp.getSchedule().getSourceAirport().getAirportLocation().equals(sourceLocation) &&
					temp.getSchedule().getDestinationAirport().getAirportLocation().equals(destinationLocation)
					
					) {
				System.out.print(temp.getSchedule().getSourceAirport().getAirportLocation() + "       \t");
				System.out.print(temp.getSchedule().getDestinationAirport().getAirportLocation() + "             \t");
				System.out.print(temp.getSchedule().getDepartureTime() + "       \t");
				System.out.print(temp.getSchedule().getArrivalTime() + "       \t");
				System.out.print(temp.getFlight().getFlightNumber() + "             \t");
				System.out.print(temp.getFlight().getCarrierName() + "\n");
				
				isFlightAvailable = true;
			}
			
		}
		
		if(isFlightAvailable) {					
			BookingServiceImpl booking = new BookingServiceImpl(); //Setup Booking
			booking.addBooking();
		}
		
		else {
			System.out.print("\nNo Flights Available\n");
			new LogOutServiceImpl();
		}
		
		
	}
	
	
	public SearchFlightsServiceImpl() {
		
						
	}
}
