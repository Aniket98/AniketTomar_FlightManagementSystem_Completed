package com.capgemini.myapp.controller;

import java.util.Scanner;

import com.capgemini.myapp.controller.*;
import com.capgemini.myapp.dao.CollectionCode;
import com.capgemini.myapp.model.Credentials;

import java.io.*;



public class LogInServiceImpl {

	String username;
	String password;
	
	Scanner scan = new Scanner(System.in);

//Constructor	
	public LogInServiceImpl(){

		//Serializing User Credentials
		try{

			Credentials user1 = new Credentials("user", "pass");
			
			FileOutputStream file = new FileOutputStream("userCredentialsFile.txt");
			ObjectOutputStream out = new ObjectOutputStream(file);
			
			out.writeObject(user1);
			out.flush();
			out.close();
			
			//System.out.println("Successfully Serialized User Credentials");

		}
		
		catch(IOException ex) {
			System.out.println("IOException is caught");
		}


		//De-serializing User Credentials
		try{

			Credentials user1 = null;
			
			FileInputStream file = new FileInputStream("userCredentialsFile.txt");
			ObjectInputStream in = new ObjectInputStream(file);
			
			user1 = (Credentials)in.readObject();
			
			in.close();
			file.close();
			
			this.username = user1.getUsername();
			this.password = user1.getPassword();

			System.out.println("____________________________ Successfully De-Serialized User Credentials ____________________________\n\n");

		}
				
		catch(IOException ex) {
			System.out.println("IOException is caught");
		}

		catch(ClassNotFoundException ex) {
			System.out.println("IOException is caught");
		}

//Login Screen - Enter and verify login credentials
		
		System.out.print(">> Username: ");
		String username = new String();
		username = scan.nextLine();
	
		System.out.print(">> Password: ");
		String password = new String();
		password = scan.nextLine();
		
		if(this.username.equals(username) && this.password.equals(password)) {
			System.out.println("\nLogin Successful!");
			System.out.println("\n___________________________________");
			
			//Calling UserMenu from Collection Code
			CollectionCode menu = new CollectionCode();
			menu.userMenu(username);
			
		}
		
		else {
			System.out.println("\nIncorrect Id or Password.");
		}
	
	}

}
