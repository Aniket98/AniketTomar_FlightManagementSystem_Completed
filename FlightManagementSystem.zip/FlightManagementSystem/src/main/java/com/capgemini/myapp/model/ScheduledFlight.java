package com.capgemini.myapp.model;

import java.io.*;

public class ScheduledFlight implements java.io.Serializable {
	
	private Flight flight;
	private Integer availableSeats;
	private Schedule schedule;

//Constructor
	
	public ScheduledFlight(Flight flight, Integer availableSeats, Schedule schedule) {
	super();
	this.flight = flight;
	this.availableSeats = availableSeats;
	this.schedule = schedule;
}

	
//testing
	private int scheduleId;
	

	public ScheduledFlight(Flight flight, int scheduleId){
		this.flight = flight;
		this.setScheduleId(scheduleId);
	}
	
	public int getScheduleId() {
		return this.scheduleId;
	}
	public void setScheduleId(int scheduleId) {
		this.scheduleId = scheduleId;
	}
//close testing

	public Flight getFlight() {
		return flight;
	}
	public void setFlight(Flight flight) {
		this.flight = flight;
	}
	public Integer getAvailableSeats() {
		return availableSeats;
	}
	public void setAvailableSeats(Integer availableSeats) {
		this.availableSeats = availableSeats;
	}
	public Schedule getSchedule() {
		return schedule;
	}
	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}

}
